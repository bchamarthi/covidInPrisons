# chartjs-tutorial
Webpage template with customizable graphs made using Chart.js